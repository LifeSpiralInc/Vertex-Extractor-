from cx_Freeze import setup, Executable

# Dependencies are automatically detected, but it might need
# fine tuning.
build_options = {'packages': ["pandas", "tkinter"], 'excludes': []}

base = 'gui'

executables = [
    Executable('VE001.py', base=base)
]

setup(name='Vertex Extractor',
      version = '0.0.1',
      description = 'Vertex Extractor is a simple tool designed to extract the point coordinates from 2D and 3D .obj files. It can also extract margin points from a 2D figure and arrange them in a clockwise order. This functionality is particularly useful for geometric morphometrics and other applications where extracting margin points in a specific order is required.',
      options = {'build_exe': build_options},
      executables = executables)
