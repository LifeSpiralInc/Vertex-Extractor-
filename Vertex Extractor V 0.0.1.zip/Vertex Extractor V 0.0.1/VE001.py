# -*- coding: utf-8 -*-
"""
Created on Tue Jul 23 19:23:38 2024

@author: paleo
"""
#%%  ------- Import Packages ------------

import os, sys
import pandas as pd
import numpy as np
import math
import itertools
from tkinter import *
from tkinter import ttk
from tkinter import filedialog

#%%  ------- Functions ------------


#obtains the necessary folder paths
def get_folder_path_input():
    global input_folder_path
    # Open and return file path
    input_folder_path= filedialog.askdirectory()
    l1 = Label(window, text = "Input Folder: " + input_folder_path,  font='Cambria 8 bold',bg="grey10", fg="white")
    l1.place(relx=0.02, y=20)

def get_folder_path_output():
    global output_folder_path
    # Open and return file path
    output_folder_path= filedialog.askdirectory()
    l2 = Label(window, text = "Output Folder: " + output_folder_path,  font='Cambria 8 bold',bg="grey10",fg="white")
    l2.place(relx=0.02, y=40)


def argsort(seq): #sorts a sequence of values
    return sorted(range(len(seq)), key=seq.__getitem__)

def all_x (x,l):
    r=True
    for k in range (len(l)):
        if l[k] !=x:
            r=False
            return r
    return r   

def checking_dimension (df): #return true if the dimensions of the configuration are three dimensional false if is two-dimensional
    i=0
    dim=True
    x=float(df.loc [3,1])
    y=float(df.loc [3,2])
    z=float(df.loc [3,3])
    xs=[]
    ys=[]
    zs=[]
    while i<len(df) :
        if df.loc [i,0]=="v":
            xs.append(float(df.loc [i,1]))
            ys.append(float(df.loc [i,2]))
            zs.append(float(df.loc [i,3]))
        i+=1  
    a= all_x(x,xs)
    b= all_x(y,ys)
    c= all_x(z,zs)
    if a or b or c :
       dim =False
    return dim

def check_position_in_list(x,l): #check the position of a value x in a list
    r=0
    for k in range (len (l)):
        if x==l[k]:
            r=k
    return r

def count_edges (face): #extract the number of conections between points
    r=[]
    l1=face
    l2=dissolve_faces(face)
    filter1=[]
    for k in range (len(l2)):
        if count_x_in_list(l2,l2[k])<3:
            filter1.append(l2[k])
    for l in range (len(filter1)):
        if count_x_in_list(r,filter1[l])<1:
            r.append(filter1[l])
    l1=find_intersecting_points(l1)
    r=r+l1
    return r

def count_x_in_list (list1,x): #counts the number of apparitions of x in a list
    r=0
    for k in range (len(list1)):
        if x == list1[k]:
            r+=1
    return r

def counterclockwise_arrangement (l): #order the list of landmarks following a counterclockwise arrangement of a list of tuple
    r=rotational_sort(l, (0,0), False)
    return r

def dissolve_faces (l): #disolves the list of lists containing the faces in a list of just the n° of the points
    r=[]
    for k in range (len(l)):
        r=r+l[k]
    return r 
    
def extract_name (string):   #extracts the name of the model
    nameinv=""
    name=""
    i = len(nameinv)-5
    while string[i]!="/":
        nameinv=nameinv+string[i]
        i=i-1
    j= len(nameinv)-1
    while j>=0:
        name=name+nameinv[j]
        j=j-1
    return name

def extract_faces (df): #extract the points that constitute the faces
    r=[]
    i=0
    while  i <len(df):
        if df.loc [i,0]=="f":
            pt1=int(df.loc[i,1]) 
            pt2=int(df.loc[i,2])
            pt3=int(df.loc[i,3])
            pt4=int(df.loc[i,4])
            face=[pt1,pt2,pt3,pt4]
            r.append(face)
        i+=1
    return r

def extract_vertices (df): #extract vertices of the obj file to a list of 2D or 3D coordinates
    r=[]
    dim=checking_dimension(df)
    i=0
    while i < len(df):
        if df.loc [i,0]=="v":
            if dim == False:
                pt_coord=(float(df.loc[i,1]),float(df.loc[i,3]))
                r.append(pt_coord)
            elif dim==True:
                pt_coord=(float(df.loc[i,1]),float(df.loc[i,2]),float(df.loc[i,3]))
                r.append(pt_coord)
            else:
                return "Error"
        i+=1
    return r

def filter_margin_points (list1,list2): #extract values of list 1 based on positions of determined by list 2
    r=[]
    if len (list1)<len (list2):
        return "Error: list 2 must be smaller than list 1"
    else:
        sorted_list2= quick_sort(list2)
        for k in range (len (sorted_list2)):
            pst=sorted_list2[k]-1
            r.append(list1[pst])
    return r

def keepextremevalues(l): #keep extreme points in cases there are several points in the middle of the  initial configuration
    l1=[]
    r=[]
    i=0
    while i < len (l) :
        pt=l[i]
        if pt[0]==0:
            l1.append(pt)
        i+=1
    l2=sorted(l1, key=lambda tup: tup[1])
    pte1=l2[0]
    pte2=l2[len(l2)-1]
    for k in range(len(l)):
        pt=l[k]
        if pt[0]==0 and ( pt==pte1 or pt==pte2):
            r.append(pt)
        elif pt[0]!=0:
            r.append(pt)
    return r

def matrix_creation(lis): #creates a 2d or 3d matrix for the obj
    array=np.zeros((len(lis),len(lis[0])+1),dtype= object)
    if len (lis[0])==2:
        r=pd.DataFrame(array, columns = ['','V1','V2'])
    if len (lis[0])==3:
        r=pd.DataFrame(array, columns = ['','V1','V2','V3'])
    i=0
    j=0
    k=1
    while i< len(lis):
        if len (lis[0])==2:
            punto=lis[i]
            r.at[j,'']=k
            r.at[j,'V1']=punto[0]
            r.loc[j,'V2']=punto[1]
        if len (lis[0])==3:
            punto=lis[i]
            r.at[j,'']=k
            r.at[j,'V1']=punto[0]
            r.loc[j,'V2']=punto[1]
            r.loc[j,'V3']=punto[2]
        i+=1
        k+=1
        j+=1
    return r

def quick_sort(l): #sorts values of a list
    if len(l) <= 1:
        return l
    else:
        return quick_sort([e for e in l[1:] if e <= l[0]]) + [l[0]] +\
            quick_sort([e for e in l[1:] if e > l[0]])

def rotational_sort(list_of_xy_coords, centre_of_rotation_xy_coord, clockwise=True): #sorts tuples following a clockwise (True) or counterclockwise (False) arrangement in a list
    cx,cy=centre_of_rotation_xy_coord
    angles = [math.atan2(x-cx, y-cy) for x,y in list_of_xy_coords]
    indices = argsort(angles)
    if clockwise:
        return [list_of_xy_coords[i] for i in indices]
    else:
        return [list_of_xy_coords[i] for i in indices[::-1]]
    
def write_txt(df, name): #writes a text file using the original name of the model
    r=""
    r=df.to_csv(output_folder_path+"/"+ name +".txt",  index=None, sep=' ', mode='w+')
    return r

def folder_extraction(input_folder_path): #extracts all the files from a folder and applies the main function to the extracted files
    model_list=[]
    r=[]
    for file in os.listdir(input_folder_path):
        if file.endswith('.obj'):
            model_list.append(file)
    for i in range (len (model_list)):
        r.append(main_function(input_folder_path+"/"+model_list[i]))
    return r  

def folder_extraction2(input_folder_path): #extracts all the files from a folder and applies a secondary function to the extracted files
    model_list=[]
    r=[]
    for file in os.listdir(input_folder_path):
        if file.endswith('.obj'):
            model_list.append(file)
    for i in range (len (model_list)):
        r.append(main_function2(input_folder_path+"/"+model_list[i]))
    return r

def sum_list (l1,l2): #sum to lists of the same lenght
    r=[]
    if len(l1)==len(l2):
        for k in range (len(l1)):
            r.append(l1[k]+l2[k])
    else:
        r="Error list must be the same lenght"
    return r

def x_in_list (x,l): #Returns True  if there is a value x in a list
    r=False
    for k in range (len(l)):
        if x == l[k]:
            r=True
    return r

def presabs_point_face (x,l): #makes a new list with the presence or absence of a point in a list
    r=[]
    for k in range(len(l)):
        if x == l[k]:
            r.append(1)
        else:
            r.append (0)
    return r

def find_intersecting_points(faces): #find intersecting points in a model
    r1=[]
    r2=[]
    l1=dissolve_faces(faces)
    l2= [i for n, i in enumerate(l1) if i not in l1[:n]]
    l3=quick_sort(l2)
    i=0
    while i < len (l3):
        pl1=[0,0,0,0]
        for k in range (len(faces)):
            pt1=l3[i]
            facex=faces[k]
            pl2=presabs_point_face(pt1, facex)
            pl1=sum_list(pl1,pl2)
        r1.append ([pt1,pl1])
        i+=1
    for h in range (len(r1)):
        pair=r1[h]
        ref=[2,1,0,1]
        if pair[1]==ref:
            r2.append(pair[0])
    return r2

def permutations(l): #provides a list with lists containing all the possible permutations of a given list of values
    l1=list(itertools.permutations(l))
    r=[]
    for k in range (len(l1)):
        r.append(list(l1[k]))
    return r

def main_function(model): #main function translates an obj to a text file with the vertice´s coordinates and just the margin points for two dimensional models
    df = pd.read_csv(model, header=None,names=[0,1,2,3,4], delimiter=' ')
    name=extract_name(model)
    dimensions=checking_dimension(df)
    if dimensions == False:
        faces=extract_faces (df)
        margin_pts=count_edges(faces)
        vertices=extract_vertices(df)
        marging_vertices=filter_margin_points(vertices,margin_pts)
        arranged_vertices=counterclockwise_arrangement(marging_vertices)
        finalresult=keepextremevalues(arranged_vertices)
        matrix=matrix_creation(finalresult)
        result=write_txt(matrix,name)
    else:
        vertices=extract_vertices(df)
        matrix=matrix_creation(vertices)
        result=write_txt(matrix,name)
    return result

def main_function2(model): #secondary function translates an obj to a text file with the vertice´s coordinates
    df = pd.read_csv(model, header=None,names=[0,1,2,3,4], delimiter=' ')
    name=extract_name(model)
    vertices=extract_vertices(df)
    matrix=matrix_creation(vertices)
    result=write_txt(matrix,name)
    return result 
   
def Ext_marg_vert_from_obj ():
    folder_extraction(input_folder_path)
    l3 = Label(window, text = "Margin coordinates extracted!!!",  font='Cambria 11 bold',bg="grey10", fg="white", width=30)
    l3.place(relx=0.5, y=90, anchor="center")
    return

def Ext_all_vert_from_obj():
    folder_extraction2(input_folder_path)
    l3 = Label(window, text = "All coordinates extracted!!!",  font='Cambria 11 bold',bg="grey10", fg="white", width=30)
    l3.place(relx=0.5, y=90, anchor="center")
    return


#%%  ------- GUI ------------

window = Tk()
window.title('Vertex Extractor V.0.1')
window.geometry("600x300+500+200")


w = Canvas(window, width=600, height=400,bg="grey10")

w.pack()
   
b1 = Button(window, text = "Select Input Folder", command = get_folder_path_input, font='Cambria 11 bold', bg="black",fg="white", width = 30)
b1.place(relx=0.5, y=150, anchor="center")

b2 = Button(window, text = "Select Output Folder", command = get_folder_path_output, font='Cambria 11 bold', bg="black",fg="white", width = 30)
b2.place(relx=0.5, y=190, anchor="center")

b3 = Button(window, text = "Extract margin point coordinates", command = Ext_marg_vert_from_obj,font='Cambria 11 bold', bg="black",fg="white", width = 30 )
b3.place(relx=0.5,y=230, anchor="center")

b4 = Button(window, text = "Extract all point coordinates", command = Ext_all_vert_from_obj , font='Cambria 11 bold', fg="white", bg="black", width = 30)
b4.place(relx=0.50, y=270, anchor="center")

window.mainloop()
